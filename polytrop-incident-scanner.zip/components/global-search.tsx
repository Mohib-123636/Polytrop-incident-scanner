'use client'

import { useRouter, useSearchParams } from 'next/navigation'
import { useState } from 'react'
import { Search, CornerDownLeft } from 'lucide-react'
import { cn } from '@/lib/utils'

function detectKind(value: string) {
  const v = value.trim()
  if (!v) return null
  if (/^0x[0-9a-fA-F]{64}$/.test(v)) return 'EVM tx'
  if (/^0x[0-9a-fA-F]{40}$/.test(v)) return 'EVM address'
  if (/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/.test(v)) return 'BTC address'
  if (/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(v)) return 'Tron address'
  if (/^[0-9a-f]{64}$/.test(v)) return 'BTC / Tron tx'
  if (/^[1-9A-HJ-NP-Za-km-z]{80,90}$/.test(v)) return 'Solana tx'
  if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(v)) return 'Solana address'
  return 'Keyword'
}

export function GlobalSearch({ size = 'hero', defaultValue }: { size?: 'hero' | 'compact'; defaultValue?: string }) {
  const router = useRouter()
  const params = useSearchParams()
  const [value, setValue] = useState(defaultValue ?? params.get('q') ?? '')
  const kind = detectKind(value)
  const hero = size === 'hero'

  return (
    <form
      role="search"
      onSubmit={(e) => {
        e.preventDefault()
        const q = value.trim()
        if (q) router.push(`/scanner/search?q=${encodeURIComponent(q)}`)
      }}
      className={cn(
        'group flex w-full items-center gap-2 rounded-md border border-border bg-card transition-colors focus-within:border-ring',
        hero ? 'h-14 px-4' : 'h-9 px-3',
      )}
    >
      <Search className={cn('shrink-0 text-muted-foreground', hero ? 'size-5' : 'size-4')} aria-hidden="true" />
      <label htmlFor={`search-${size}`} className="sr-only">
        Address or transaction hash
      </label>
      <input
        id={`search-${size}`}
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={hero ? 'Address or transaction hash Search…' : 'Search address / tx…'}
        autoComplete="off"
        spellCheck={false}
        className={cn(
          'min-w-0 flex-1 bg-transparent font-mono text-foreground outline-none placeholder:text-muted-foreground',
          hero ? 'text-base' : 'text-sm',
        )}
      />
      {kind && (
        <span
          className={cn(
            'hidden shrink-0 rounded-sm border border-border px-1.5 py-0.5 font-mono text-muted-foreground sm:inline',
            hero ? 'text-xs' : 'text-[11px]',
          )}
        >
          {kind}
        </span>
      )}
      {hero && (
        <button
          type="submit"
          className="flex shrink-0 items-center gap-1.5 rounded-sm bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
        >
          Scan
          <CornerDownLeft className="size-3.5" aria-hidden="true" />
        </button>
      )}
    </form>
  )
}
