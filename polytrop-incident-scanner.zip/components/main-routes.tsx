import { ChevronRight } from 'lucide-react'
import type { MainRoute } from '@/lib/data'
import { formatUsd, truncateHash } from '@/lib/format'
import { ChainIcon, StatusBadge } from '@/components/badges'
import { cn } from '@/lib/utils'

const NODE_TONE = {
  tainted: 'border-tainted/30',
  frozen: 'border-frozen/50 bg-frozen/5',
  service: 'border-service/50 bg-service/5',
} as const

export function MainRoutes({ routes }: { routes: MainRoute[] }) {
  if (routes.length === 0) {
    return <p className="rounded-md border border-border bg-card p-8 text-center text-sm text-muted-foreground">No terminal routes identified yet.</p>
  }
  return (
    <ol className="flex flex-col gap-3">
      {routes.map((route, i) => {
        const terminal = route.path[route.path.length - 1]
        return (
          <li key={route.id} className="flex flex-col gap-3 rounded-md border border-border bg-card p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-muted-foreground">{`Route ${String(i + 1).padStart(2, '0')}`}</span>
                <span className="font-mono text-sm font-semibold tabular-nums">{formatUsd(route.usd)}</span>
                <span className="font-mono text-xs text-muted-foreground">{`${route.hops} hops`}</span>
              </div>
              <StatusBadge status={terminal.status} />
            </div>
            <div className="flex items-center gap-1 overflow-x-auto pb-1">
              {route.path.map((step, idx) => (
                <div key={`${route.id}-${idx}`} className="flex shrink-0 items-center gap-1">
                  <div className={cn('flex items-center gap-2 rounded-sm border bg-secondary px-2 py-1.5', NODE_TONE[step.status])}>
                    <ChainIcon chain={step.chain} className="h-4 w-8 text-[9px]" />
                    <div className="flex flex-col">
                      <span className="font-mono text-xs" title={step.address}>
                        {truncateHash(step.address, 5, 4)}
                      </span>
                      {step.label && <span className="text-[10px] leading-tight text-muted-foreground">{step.label}</span>}
                    </div>
                  </div>
                  {idx < route.path.length - 1 && <ChevronRight className="size-3.5 text-muted-foreground" aria-hidden="true" />}
                </div>
              ))}
            </div>
          </li>
        )
      })}
    </ol>
  )
}
