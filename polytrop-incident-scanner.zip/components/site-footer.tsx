import Link from 'next/link'

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-6 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between md:px-6">
        <p className="font-mono">
          {'Tracewire Scanner — simulated forensic dataset for demonstration. Addresses and hashes are synthetic.'}
        </p>
        <nav aria-label="Footer" className="flex gap-4">
          <Link href="/scanner/data" className="hover:text-foreground">
            API docs
          </Link>
          <Link href="/api/export/addresses" className="hover:text-foreground">
            Addresses CSV
          </Link>
          <Link href="/api/export/services" className="hover:text-foreground">
            Services CSV
          </Link>
        </nav>
      </div>
    </footer>
  )
}
