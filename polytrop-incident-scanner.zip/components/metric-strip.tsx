import { cn } from '@/lib/utils'

export type Metric = { label: string; value: string; hint?: string; tone?: 'tainted' | 'frozen' | 'service' }

const TONE = { tainted: 'text-tainted', frozen: 'text-frozen', service: 'text-service' } as const

export function MetricStrip({ metrics }: { metrics: Metric[] }) {
  return (
    <dl className="grid grid-cols-2 overflow-hidden rounded-md border border-border bg-border lg:grid-cols-[repeat(var(--cols),minmax(0,1fr))]" style={{ '--cols': metrics.length, gap: 1 } as React.CSSProperties}>
      {metrics.map((m) => (
        <div key={m.label} className="flex flex-col gap-1 bg-card p-4">
          <dt className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">{m.label}</dt>
          <dd className={cn('font-mono text-2xl font-semibold tabular-nums tracking-tight', m.tone && TONE[m.tone])}>{m.value}</dd>
          {m.hint && <dd className="text-xs text-muted-foreground">{m.hint}</dd>}
        </div>
      ))}
    </dl>
  )
}
