import { CHAIN_LABEL, CHAIN_TICKER, type AddressStatus, type Chain } from '@/lib/data'
import { cn } from '@/lib/utils'

const CHAIN_STYLE: Record<Chain, string> = {
  bitcoin: 'border-service/40 text-service',
  evm: 'border-ring/60 text-foreground',
  tron: 'border-tainted/40 text-tainted',
  solana: 'border-frozen/40 text-frozen',
}

export function ChainIcon({ chain, className }: { chain: Chain; className?: string }) {
  return (
    <span
      title={CHAIN_LABEL[chain]}
      className={cn(
        'inline-flex h-5 w-9 shrink-0 items-center justify-center rounded-sm border bg-secondary font-mono text-[10px] font-semibold tracking-wide',
        CHAIN_STYLE[chain],
        className,
      )}
    >
      <span aria-hidden="true">{CHAIN_TICKER[chain]}</span>
      <span className="sr-only">{CHAIN_LABEL[chain]}</span>
    </span>
  )
}

const STATUS_STYLE: Record<AddressStatus, { label: string; className: string }> = {
  tainted: { label: 'Tainted', className: 'border-tainted/40 bg-tainted/10 text-tainted' },
  frozen: { label: 'Frozen', className: 'border-frozen/40 bg-frozen/10 text-frozen' },
  service: { label: 'Reached service', className: 'border-service/40 bg-service/10 text-service' },
}

export function StatusBadge({ status }: { status: AddressStatus }) {
  const s = STATUS_STYLE[status]
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-sm border px-2 py-0.5 font-mono text-[11px] font-medium uppercase tracking-wide',
        s.className,
      )}
    >
      <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />
      {s.label}
    </span>
  )
}

const STATE_STYLE = {
  live: 'border-tainted/40 bg-tainted/10 text-tainted',
  contained: 'border-service/40 bg-service/10 text-service',
  archived: 'border-border bg-secondary text-muted-foreground',
} as const

export function IncidentStateBadge({ state }: { state: keyof typeof STATE_STYLE }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-sm border px-2 py-0.5 font-mono text-[11px] font-medium uppercase tracking-wide',
        STATE_STYLE[state],
      )}
    >
      {state === 'live' && <span className="size-1.5 animate-pulse rounded-full bg-current" aria-hidden="true" />}
      {state}
    </span>
  )
}
