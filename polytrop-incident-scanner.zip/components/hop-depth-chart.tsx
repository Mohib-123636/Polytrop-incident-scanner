'use client'

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { formatUsd } from '@/lib/format'

export type HopBucket = { hop: string; tainted: number; frozen: number; service: number }

export function HopDepthChart({ data }: { data: HopBucket[] }) {
  return (
    <div className="flex flex-col rounded-md border border-border bg-card">
      <div className="border-b border-border px-4 py-3">
        <h3 className="text-sm font-semibold">Value by hop depth</h3>
        <p className="text-xs text-muted-foreground">USD transferred at each hop, split by current status.</p>
      </div>
      <div className="h-64 px-2 py-4">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 4, right: 12, left: 4, bottom: 0 }}>
            <CartesianGrid stroke="var(--border)" vertical={false} />
            <XAxis dataKey="hop" tick={{ fill: 'var(--muted-foreground)', fontSize: 11, fontFamily: 'var(--font-mono)' }} axisLine={false} tickLine={false} />
            <YAxis
              tickFormatter={(v: number) => formatUsd(v)}
              tick={{ fill: 'var(--muted-foreground)', fontSize: 11, fontFamily: 'var(--font-mono)' }}
              axisLine={false}
              tickLine={false}
              width={64}
            />
            <Tooltip
              cursor={{ fill: 'var(--accent)', opacity: 0.4 }}
              contentStyle={{
                background: 'var(--card)',
                border: '1px solid var(--border)',
                borderRadius: 4,
                fontFamily: 'var(--font-mono)',
                fontSize: 12,
              }}
              labelStyle={{ color: 'var(--foreground)' }}
              formatter={(value) => formatUsd(Number(value))}
            />
            <Bar dataKey="tainted" name="Tainted" stackId="a" fill="var(--tainted)" />
            <Bar dataKey="service" name="Reached service" stackId="a" fill="var(--service)" />
            <Bar dataKey="frozen" name="Frozen" stackId="a" fill="var(--frozen)" radius={[2, 2, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
