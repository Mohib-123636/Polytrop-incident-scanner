'use client'

import { useState } from 'react'
import { Check, Copy } from 'lucide-react'
import { truncateHash } from '@/lib/format'
import { cn } from '@/lib/utils'

export function CopyButton({ value, label = 'Copy' }: { value: string; label?: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      type="button"
      onClick={async (e) => {
        e.stopPropagation()
        await navigator.clipboard.writeText(value)
        setCopied(true)
        setTimeout(() => setCopied(false), 1400)
      }}
      className="inline-flex size-6 shrink-0 items-center justify-center rounded-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
      aria-label={copied ? 'Copied' : `${label} ${value}`}
    >
      {copied ? <Check className="size-3.5 text-frozen" aria-hidden="true" /> : <Copy className="size-3.5" aria-hidden="true" />}
    </button>
  )
}

export function HashCell({
  value,
  head = 8,
  tail = 6,
  className,
}: {
  value: string
  head?: number
  tail?: number
  className?: string
}) {
  return (
    <span className={cn('inline-flex items-center gap-1', className)}>
      <span className="font-mono text-[13px] text-foreground" title={value}>
        {truncateHash(value, head, tail)}
      </span>
      <CopyButton value={value} />
    </span>
  )
}
