'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import {
  type ColumnDef,
  type SortingState,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table'
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight, Filter } from 'lucide-react'
import { CHAIN_LABEL, type AddressStatus, type Chain, type FlaggedAddress } from '@/lib/data'
import { formatDateTime, formatNumber, formatUsd } from '@/lib/format'
import { ChainIcon, StatusBadge } from '@/components/badges'
import { HashCell } from '@/components/hash-cell'
import { cn } from '@/lib/utils'

export type AddressRow = FlaggedAddress & { incidentSlug?: string; incidentName?: string }

const CHAINS: Chain[] = ['bitcoin', 'tron', 'evm', 'solana']
const SIZES = [
  { label: 'All sizes', min: 0 },
  { label: '> $50K', min: 50_000 },
  { label: '> $500K', min: 500_000 },
  { label: '> $2M', min: 2_000_000 },
]
const STATUSES: { value: AddressStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'tainted', label: 'Tainted' },
  { value: 'frozen', label: 'Frozen' },
  { value: 'service', label: 'Services' },
]

function SortIcon({ dir }: { dir: false | 'asc' | 'desc' }) {
  if (dir === 'asc') return <ArrowUp className="size-3" aria-hidden="true" />
  if (dir === 'desc') return <ArrowDown className="size-3" aria-hidden="true" />
  return <ArrowUpDown className="size-3 opacity-40" aria-hidden="true" />
}

function ToggleChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        'inline-flex h-8 items-center gap-2 rounded-sm border px-2.5 text-xs font-medium transition-colors',
        active ? 'border-ring bg-accent text-foreground' : 'border-border text-muted-foreground hover:text-foreground',
      )}
    >
      {children}
    </button>
  )
}

export function AddressTable({
  rows,
  showIncident = false,
  pageSize = 20,
  title = 'Flagged addresses',
}: {
  rows: AddressRow[]
  showIncident?: boolean
  pageSize?: number
  title?: string
}) {
  const [chains, setChains] = useState<Set<Chain>>(new Set())
  const [minSize, setMinSize] = useState(0)
  const [status, setStatus] = useState<AddressStatus | 'all'>('all')
  const [sorting, setSorting] = useState<SortingState>([{ id: 'transferredUsd', desc: true }])

  const availableChains = useMemo(() => CHAINS.filter((c) => rows.some((r) => r.chain === c)), [rows])

  const filtered = useMemo(
    () =>
      rows.filter(
        (r) =>
          (chains.size === 0 || chains.has(r.chain)) &&
          r.transferredUsd > minSize &&
          (status === 'all' || r.status === status),
      ),
    [rows, chains, minSize, status],
  )

  const columns = useMemo<ColumnDef<AddressRow>[]>(() => {
    const cols: ColumnDef<AddressRow>[] = [
      {
        id: 'address',
        accessorKey: 'address',
        header: 'Source address',
        enableSorting: false,
        cell: ({ row }) => (
          <div className="flex items-center gap-2">
            <ChainIcon chain={row.original.chain} />
            <div className="flex min-w-0 flex-col">
              <HashCell value={row.original.address} />
              {row.original.label && <span className="truncate text-[11px] text-muted-foreground">{row.original.label}</span>}
            </div>
          </div>
        ),
      },
    ]
    if (showIncident) {
      cols.push({
        id: 'incident',
        accessorKey: 'incidentName',
        header: 'Incident',
        enableSorting: false,
        cell: ({ row }) =>
          row.original.incidentSlug ? (
            <Link href={`/scanner/incident/${row.original.incidentSlug}`} className="text-sm text-foreground underline-offset-4 hover:underline">
              {row.original.incidentName}
            </Link>
          ) : null,
      })
    }
    cols.push(
      {
        id: 'hop',
        accessorKey: 'hop',
        header: 'Hop',
        cell: ({ getValue }) => <span className="font-mono text-sm text-muted-foreground">{`H${getValue<number>()}`}</span>,
      },
      {
        id: 'addedAt',
        accessorKey: 'addedAt',
        header: 'Added',
        cell: ({ getValue }) => <span className="whitespace-nowrap font-mono text-xs text-muted-foreground">{formatDateTime(getValue<string>())}</span>,
      },
      {
        id: 'transferredUsd',
        accessorKey: 'transferredUsd',
        header: 'Transferred',
        cell: ({ getValue }) => (
          <span className="whitespace-nowrap font-mono text-sm font-medium tabular-nums" title={formatUsd(getValue<number>(), false)}>
            {formatUsd(getValue<number>())}
          </span>
        ),
      },
      {
        id: 'downstream',
        accessorKey: 'downstream',
        header: 'Downstream',
        cell: ({ getValue }) => <span className="font-mono text-sm tabular-nums">{formatNumber(getValue<number>())}</span>,
      },
      {
        id: 'lastMoveAt',
        accessorKey: 'lastMoveAt',
        header: 'Last move',
        cell: ({ getValue }) => <span className="whitespace-nowrap font-mono text-xs text-muted-foreground">{formatDateTime(getValue<string>())}</span>,
      },
      {
        id: 'status',
        accessorKey: 'status',
        header: 'Status',
        cell: ({ getValue }) => <StatusBadge status={getValue<AddressStatus>()} />,
      },
    )
    return cols
  }, [showIncident])

  const table = useReactTable({
    data: filtered,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageSize } },
    autoResetPageIndex: true,
  })

  const totalUsd = filtered.reduce((s, r) => s + r.transferredUsd, 0)
  const { pageIndex } = table.getState().pagination

  return (
    <section aria-label={title} className="flex flex-col rounded-md border border-border bg-card">
      <div className="flex flex-col gap-3 border-b border-border p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-sm font-semibold">{title}</h3>
          <p className="font-mono text-xs text-muted-foreground">
            {`${formatNumber(filtered.length)} of ${formatNumber(rows.length)} addresses · ${formatUsd(totalUsd)} in view`}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
          <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Filter by chain">
            <Filter className="size-3.5 text-muted-foreground" aria-hidden="true" />
            {availableChains.map((c) => (
              <ToggleChip
                key={c}
                active={chains.has(c)}
                onClick={() =>
                  setChains((prev) => {
                    const next = new Set(prev)
                    if (next.has(c)) next.delete(c)
                    else next.add(c)
                    return next
                  })
                }
              >
                <ChainIcon chain={c} className="h-4 w-8 text-[9px]" />
                {CHAIN_LABEL[c]}
              </ToggleChip>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Filter by transfer size">
            {SIZES.map((s) => (
              <ToggleChip key={s.label} active={minSize === s.min} onClick={() => setMinSize(s.min)}>
                <span className="font-mono">{s.label}</span>
              </ToggleChip>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-1.5" role="group" aria-label="Filter by status">
            {STATUSES.map((s) => (
              <ToggleChip key={s.value} active={status === s.value} onClick={() => setStatus(s.value)}>
                {s.label}
              </ToggleChip>
            ))}
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[860px] border-collapse text-left">
          <thead>
            {table.getHeaderGroups().map((hg) => (
              <tr key={hg.id} className="border-b border-border">
                {hg.headers.map((header) => {
                  const sorted = header.column.getIsSorted()
                  return (
                    <th
                      key={header.id}
                      scope="col"
                      aria-sort={sorted === 'asc' ? 'ascending' : sorted === 'desc' ? 'descending' : 'none'}
                      className="px-4 py-2.5 font-mono text-[11px] font-medium uppercase tracking-wider text-muted-foreground"
                    >
                      {header.column.getCanSort() ? (
                        <button
                          type="button"
                          onClick={header.column.getToggleSortingHandler()}
                          className="inline-flex items-center gap-1 uppercase hover:text-foreground"
                        >
                          {flexRender(header.column.columnDef.header, header.getContext())}
                          <SortIcon dir={sorted} />
                        </button>
                      ) : (
                        flexRender(header.column.columnDef.header, header.getContext())
                      )}
                    </th>
                  )
                })}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="px-4 py-12 text-center text-sm text-muted-foreground">
                  No addresses match the current filters.
                </td>
              </tr>
            ) : (
              table.getRowModel().rows.map((row) => (
                <tr key={row.id} className="border-b border-border/60 transition-colors last:border-0 hover:bg-secondary/60">
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id} className="px-4 py-2.5 align-middle">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between gap-2 border-t border-border px-4 py-2.5">
        <p className="font-mono text-xs text-muted-foreground">
          {`Page ${table.getPageCount() === 0 ? 0 : pageIndex + 1} / ${table.getPageCount()}`}
        </p>
        <div className="flex gap-1">
          <button
            type="button"
            onClick={() => table.previousPage()}
            disabled={!table.getCanPreviousPage()}
            className="inline-flex size-8 items-center justify-center rounded-sm border border-border text-muted-foreground hover:text-foreground disabled:opacity-40"
            aria-label="Previous page"
          >
            <ChevronLeft className="size-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={() => table.nextPage()}
            disabled={!table.getCanNextPage()}
            className="inline-flex size-8 items-center justify-center rounded-sm border border-border text-muted-foreground hover:text-foreground disabled:opacity-40"
            aria-label="Next page"
          >
            <ChevronRight className="size-4" aria-hidden="true" />
          </button>
        </div>
      </div>
    </section>
  )
}
