'use client'

import { useRef, useState } from 'react'
import { Database, Download, KeyRound, Network, X } from 'lucide-react'
import { CopyButton } from '@/components/hash-cell'
import { cn } from '@/lib/utils'

function generateKey() {
  const bytes = new Uint8Array(24)
  crypto.getRandomValues(bytes)
  return `tw_live_${Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('')}`
}

const SCOPES = ['incidents:read', 'addresses:read', 'services:read', 'alerts:subscribe'] as const

export function ExportHub({ incidentSlug, variant = 'panel' }: { incidentSlug?: string; variant?: 'panel' | 'inline' }) {
  const dialogRef = useRef<HTMLDialogElement>(null)
  const [keyName, setKeyName] = useState('forensics-pipeline')
  const [scopes, setScopes] = useState<Set<string>>(new Set(['incidents:read', 'addresses:read']))
  const [issued, setIssued] = useState<{ name: string; key: string; scopes: string[] } | null>(null)

  const qs = incidentSlug ? `?incident=${incidentSlug}` : ''

  const actions = [
    {
      href: `/api/export/addresses${qs}`,
      icon: Database,
      title: 'Get the addresses CSV',
      body: incidentSlug ? 'Every flagged address in this incident.' : 'Every flagged address across all incidents.',
    },
    {
      href: `/api/export/services${qs}`,
      icon: Network,
      title: 'Get the services CSV',
      body: 'Exchanges, bridges and OTC desks that received tainted value.',
    },
  ]

  return (
    <>
      <div className={cn('grid gap-3', variant === 'panel' ? 'md:grid-cols-3' : 'sm:grid-cols-3')}>
        {actions.map((a) => (
          <a
            key={a.title}
            href={a.href}
            download
            className="group flex flex-col gap-3 rounded-md border border-border bg-card p-4 transition-colors hover:border-ring"
          >
            <div className="flex items-center justify-between">
              <a.icon className="size-5 text-muted-foreground" aria-hidden="true" />
              <Download className="size-4 text-muted-foreground transition-colors group-hover:text-foreground" aria-hidden="true" />
            </div>
            <div>
              <p className="text-sm font-semibold">{a.title}</p>
              <p className="text-xs leading-relaxed text-muted-foreground">{a.body}</p>
            </div>
          </a>
        ))}
        <button
          type="button"
          onClick={() => {
            setIssued(null)
            dialogRef.current?.showModal()
          }}
          className="group flex flex-col gap-3 rounded-md border border-border bg-card p-4 text-left transition-colors hover:border-ring"
        >
          <div className="flex items-center justify-between">
            <KeyRound className="size-5 text-muted-foreground" aria-hidden="true" />
            <span className="font-mono text-[11px] text-muted-foreground">REST · JSON</span>
          </div>
          <div>
            <p className="text-sm font-semibold">Obtain API keys</p>
            <p className="text-xs leading-relaxed text-muted-foreground">Stream incidents and address risk into your own stack.</p>
          </div>
        </button>
      </div>

      <dialog
        ref={dialogRef}
        aria-labelledby="api-key-title"
        className="m-auto w-[min(32rem,calc(100vw-2rem))] rounded-md border border-border bg-card p-0 text-card-foreground backdrop:bg-background/80 backdrop:backdrop-blur-sm"
        onClick={(e) => {
          if (e.target === dialogRef.current) dialogRef.current?.close()
        }}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h2 id="api-key-title" className="text-base font-semibold">
            {issued ? 'API key issued' : 'Create API key'}
          </h2>
          <button
            type="button"
            onClick={() => dialogRef.current?.close()}
            className="inline-flex size-8 items-center justify-center rounded-sm text-muted-foreground hover:bg-accent hover:text-foreground"
            aria-label="Close"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>

        {issued ? (
          <div className="flex flex-col gap-4 p-5">
            <p className="text-sm leading-relaxed text-muted-foreground">
              {"Copy this key now — it won't be shown again. Send it as a bearer token on every request."}
            </p>
            <div className="flex items-center gap-2 rounded-sm border border-border bg-background px-3 py-2">
              <code className="flex-1 break-all font-mono text-xs">{issued.key}</code>
              <CopyButton value={issued.key} label="Copy API key" />
            </div>
            <pre className="overflow-x-auto rounded-sm border border-border bg-background p-3 font-mono text-[11px] leading-relaxed text-muted-foreground">
              {`curl https://scanner.tracewire.dev/api/v1/incidents \\\n  -H "Authorization: Bearer ${issued.key.slice(0, 16)}…"`}
            </pre>
            <div className="flex flex-wrap gap-1.5">
              {issued.scopes.map((s) => (
                <span key={s} className="rounded-sm border border-border px-1.5 py-0.5 font-mono text-[11px] text-muted-foreground">
                  {s}
                </span>
              ))}
            </div>
            <button
              type="button"
              onClick={() => dialogRef.current?.close()}
              className="h-9 rounded-sm bg-primary text-sm font-medium text-primary-foreground hover:opacity-90"
            >
              Done
            </button>
          </div>
        ) : (
          <form
            className="flex flex-col gap-4 p-5"
            onSubmit={(e) => {
              e.preventDefault()
              if (!keyName.trim() || scopes.size === 0) return
              setIssued({ name: keyName.trim(), key: generateKey(), scopes: [...scopes] })
            }}
          >
            <div className="flex flex-col gap-1.5">
              <label htmlFor="key-name" className="text-xs font-medium text-muted-foreground">
                Key name
              </label>
              <input
                id="key-name"
                value={keyName}
                onChange={(e) => setKeyName(e.target.value)}
                required
                maxLength={48}
                className="h-9 rounded-sm border border-border bg-background px-3 font-mono text-sm outline-none focus:border-ring"
              />
            </div>
            <fieldset className="flex flex-col gap-2">
              <legend className="mb-1.5 text-xs font-medium text-muted-foreground">Scopes</legend>
              {SCOPES.map((s) => (
                <label key={s} className="flex items-center gap-2 font-mono text-sm">
                  <input
                    type="checkbox"
                    checked={scopes.has(s)}
                    onChange={() =>
                      setScopes((prev) => {
                        const next = new Set(prev)
                        if (next.has(s)) next.delete(s)
                        else next.add(s)
                        return next
                      })
                    }
                    className="size-4 accent-[var(--frozen)]"
                  />
                  {s}
                </label>
              ))}
            </fieldset>
            <button
              type="submit"
              disabled={scopes.size === 0}
              className="h-9 rounded-sm bg-primary text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-40"
            >
              Generate key
            </button>
          </form>
        )}
      </dialog>
    </>
  )
}
