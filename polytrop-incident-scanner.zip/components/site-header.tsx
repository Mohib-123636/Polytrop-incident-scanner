import { Suspense } from 'react'
import Link from 'next/link'
import { Radar } from 'lucide-react'
import { GlobalSearch } from '@/components/global-search'

const NAV = [
  { href: '/scanner', label: 'Scanner' },
  { href: '/scanner#directory', label: 'Incidents' },
  { href: '/scanner/data', label: 'Data & API' },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-7xl items-center gap-6 px-4 md:px-6">
        <Link href="/scanner" className="flex shrink-0 items-center gap-2" aria-label="Tracewire Scanner home">
          <span className="flex size-7 items-center justify-center rounded-sm border border-tainted/40 bg-tainted/10 text-tainted">
            <Radar className="size-4" aria-hidden="true" />
          </span>
          <span className="font-mono text-sm font-semibold tracking-tight">
            tracewire<span className="text-muted-foreground">/scanner</span>
          </span>
        </Link>
        <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-sm px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="ml-auto w-full max-w-sm">
          <Suspense fallback={<div className="h-9 rounded-md border border-border bg-card" />}>
            <GlobalSearch size="compact" />
          </Suspense>
        </div>
      </div>
    </header>
  )
}
