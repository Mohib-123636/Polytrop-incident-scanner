import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import type { Incident } from '@/lib/data'
import { formatDate, formatDuration, formatUsd } from '@/lib/format'
import { ChainIcon, IncidentStateBadge } from '@/components/badges'

export function IncidentDirectory({ incidents }: { incidents: Incident[] }) {
  return (
    <div className="overflow-hidden rounded-md border border-border bg-card">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[880px] text-left">
          <thead>
            <tr className="border-b border-border font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
              <th scope="col" className="px-4 py-2.5 font-medium">Incident</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Date</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Chains</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Stolen</th>
              <th scope="col" className="w-48 px-4 py-2.5 font-medium">Traced / Frozen</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Hops</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Time to flag</th>
              <th scope="col" className="px-4 py-2.5 font-medium">State</th>
            </tr>
          </thead>
          <tbody>
            {incidents.map((inc) => {
              const traced = (inc.tracedUsd / inc.stolenUsd) * 100
              const frozen = (inc.frozenUsd / inc.stolenUsd) * 100
              return (
                <tr key={inc.slug} className="group relative border-b border-border/60 last:border-0 hover:bg-secondary/60">
                  <td className="px-4 py-3">
                    <Link href={`/scanner/incident/${inc.slug}`} className="flex items-center gap-1.5 text-sm font-medium after:absolute after:inset-0">
                      {inc.name}
                      <ArrowUpRight className="size-3.5 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" aria-hidden="true" />
                    </Link>
                    <p className="text-xs text-muted-foreground">{inc.victim}</p>
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 font-mono text-xs text-muted-foreground">{formatDate(inc.date)}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      {inc.chains.map((c) => (
                        <ChainIcon key={c} chain={c} />
                      ))}
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-sm font-semibold tabular-nums text-tainted">{formatUsd(inc.stolenUsd)}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1.5">
                      <div className="relative h-1.5 overflow-hidden rounded-full bg-secondary" aria-hidden="true">
                        <div className="absolute inset-y-0 left-0 bg-ring" style={{ width: `${traced}%` }} />
                        <div className="absolute inset-y-0 left-0 bg-frozen" style={{ width: `${frozen}%` }} />
                      </div>
                      <span className="font-mono text-[11px] text-muted-foreground">
                        {`${traced.toFixed(0)}% traced · `}
                        <span className="text-frozen">{`${frozen.toFixed(1)}% frozen`}</span>
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-sm tabular-nums">{inc.maxHop}</td>
                  <td className="px-4 py-3 font-mono text-sm tabular-nums">{formatDuration(inc.timeToFlagMin)}</td>
                  <td className="px-4 py-3">
                    <IncidentStateBadge state={inc.state} />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
