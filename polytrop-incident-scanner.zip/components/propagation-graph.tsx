'use client'

import { useMemo, useState } from 'react'
import type { FlaggedAddress } from '@/lib/data'
import { formatUsd, truncateHash } from '@/lib/format'
import { ChainIcon, StatusBadge } from '@/components/badges'

const COL_W = 150
const ROW_H = 44
const PAD_X = 40
const PAD_Y = 30
const MAX_PER_HOP = 9

const STATUS_FILL = {
  tainted: 'var(--tainted)',
  frozen: 'var(--frozen)',
  service: 'var(--service)',
} as const

type Node = FlaggedAddress & { x: number; y: number; r: number }

export function PropagationGraph({ addresses }: { addresses: FlaggedAddress[] }) {
  const [activeId, setActiveId] = useState<string | null>(null)

  const { nodes, edges, width, height, maxHop } = useMemo(() => {
    const byId = new Map(addresses.map((a) => [a.id, a]))
    const keep = new Set<string>()
    const ranked = [...addresses].sort((a, b) => b.transferredUsd - a.transferredUsd)
    const perHop = new Map<number, number>()

    for (const a of ranked) {
      if ((perHop.get(a.hop) ?? 0) >= MAX_PER_HOP) continue
      const chain: FlaggedAddress[] = []
      let cursor: FlaggedAddress | undefined = a
      let fits = true
      while (cursor && !keep.has(cursor.id)) {
        if ((perHop.get(cursor.hop) ?? 0) + chain.filter((c) => c.hop === cursor!.hop).length >= MAX_PER_HOP) {
          fits = false
          break
        }
        chain.push(cursor)
        cursor = cursor.parentId ? byId.get(cursor.parentId) : undefined
      }
      if (!fits) continue
      for (const c of chain) {
        keep.add(c.id)
        perHop.set(c.hop, (perHop.get(c.hop) ?? 0) + 1)
      }
    }

    const kept = addresses.filter((a) => keep.has(a.id))
    const hopMax = Math.max(...kept.map((k) => k.hop))
    const maxRows = Math.max(...[...perHop.values()])
    const h = PAD_Y * 2 + (maxRows - 1) * ROW_H
    const maxUsd = Math.max(...kept.filter((k) => k.hop > 0).map((k) => k.transferredUsd), 1)

    const positioned = new Map<string, Node>()
    for (let hop = 0; hop <= hopMax; hop++) {
      const col = kept
        .filter((k) => k.hop === hop)
        .sort((a, b) => {
          const pa = a.parentId ? positioned.get(a.parentId)?.y ?? 0 : 0
          const pb = b.parentId ? positioned.get(b.parentId)?.y ?? 0 : 0
          return pa - pb || b.transferredUsd - a.transferredUsd
        })
      const offset = (h - PAD_Y * 2 - (col.length - 1) * ROW_H) / 2
      col.forEach((a, i) => {
        const r = hop === 0 ? 11 : 4 + Math.sqrt(a.transferredUsd / maxUsd) * 7
        positioned.set(a.id, { ...a, x: PAD_X + hop * COL_W, y: PAD_Y + offset + i * ROW_H, r })
      })
    }

    const nodeList = [...positioned.values()]
    const edgeList = nodeList
      .filter((n) => n.parentId && positioned.has(n.parentId))
      .map((n) => ({ from: positioned.get(n.parentId!)!, to: n }))

    return { nodes: nodeList, edges: edgeList, width: PAD_X * 2 + hopMax * COL_W + 80, height: h, maxHop: hopMax }
  }, [addresses])

  const active = nodes.find((n) => n.id === activeId) ?? null
  const lineage = useMemo(() => {
    const ids = new Set<string>()
    if (!active) return ids
    const map = new Map(nodes.map((n) => [n.id, n]))
    let c: Node | undefined = active
    while (c) {
      ids.add(c.id)
      c = c.parentId ? map.get(c.parentId) : undefined
    }
    return ids
  }, [active, nodes])

  return (
    <div className="flex flex-col rounded-md border border-border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3">
        <div>
          <h3 className="text-sm font-semibold">Propagation tree</h3>
          <p className="text-xs text-muted-foreground">
            {`Largest flows per hop, H0 → H${maxHop}. Hover a node to isolate its path.`}
          </p>
        </div>
        <ul className="flex gap-3 font-mono text-[11px] text-muted-foreground">
          {(['tainted', 'frozen', 'service'] as const).map((s) => (
            <li key={s} className="flex items-center gap-1.5">
              <span className="size-2 rounded-full" style={{ background: STATUS_FILL[s] }} aria-hidden="true" />
              {s === 'service' ? 'Service' : s[0].toUpperCase() + s.slice(1)}
            </li>
          ))}
        </ul>
      </div>
      <div className="relative overflow-x-auto">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          width={width}
          height={height}
          className="block min-w-full"
          role="img"
          aria-label={`Propagation tree with ${nodes.length} addresses across ${maxHop + 1} hops`}
        >
          {Array.from({ length: maxHop + 1 }, (_, hop) => (
            <g key={hop}>
              <line x1={PAD_X + hop * COL_W} x2={PAD_X + hop * COL_W} y1={8} y2={height - 8} stroke="var(--border)" strokeDasharray="2 4" />
              <text x={PAD_X + hop * COL_W} y={14} textAnchor="middle" className="fill-muted-foreground font-mono text-[10px]">
                {`H${hop}`}
              </text>
            </g>
          ))}
          {edges.map(({ from, to }) => {
            const mx = (from.x + to.x) / 2
            const highlighted = lineage.has(to.id) && lineage.has(from.id)
            return (
              <path
                key={`${from.id}-${to.id}`}
                d={`M${from.x},${from.y} C${mx},${from.y} ${mx},${to.y} ${to.x},${to.y}`}
                fill="none"
                stroke={highlighted ? STATUS_FILL[to.status] : 'var(--ring)'}
                strokeOpacity={active ? (highlighted ? 0.95 : 0.12) : 0.4}
                strokeWidth={highlighted ? 2 : 1 + Math.min(2, to.r / 6)}
              />
            )
          })}
          {nodes.map((n) => (
            <g
              key={n.id}
              tabIndex={0}
              role="button"
              aria-label={`${n.address}, ${formatUsd(n.transferredUsd)}, ${n.status}`}
              onMouseEnter={() => setActiveId(n.id)}
              onMouseLeave={() => setActiveId(null)}
              onFocus={() => setActiveId(n.id)}
              onBlur={() => setActiveId(null)}
              className="cursor-pointer outline-none"
              opacity={active && !lineage.has(n.id) ? 0.25 : 1}
            >
              <circle cx={n.x} cy={n.y} r={n.r + 5} fill="transparent" />
              <circle cx={n.x} cy={n.y} r={n.r} fill={STATUS_FILL[n.status]} fillOpacity={0.18} stroke={STATUS_FILL[n.status]} strokeWidth={1.5} />
              <text x={n.x + n.r + 5} y={n.y + 3} className="fill-muted-foreground font-mono text-[9px]">
                {truncateHash(n.address, 4, 3)}
              </text>
            </g>
          ))}
        </svg>
      </div>
      <div className="flex min-h-14 items-center gap-3 border-t border-border px-4 py-3" aria-live="polite">
        {active ? (
          <>
            <ChainIcon chain={active.chain} />
            <span className="font-mono text-xs break-all">{active.address}</span>
            <span className="font-mono text-sm font-medium tabular-nums">{formatUsd(active.transferredUsd)}</span>
            <span className="font-mono text-xs text-muted-foreground">{`H${active.hop}`}</span>
            <StatusBadge status={active.status} />
          </>
        ) : (
          <span className="text-xs text-muted-foreground">Select a node to inspect the address and value at that hop.</span>
        )}
      </div>
    </div>
  )
}
