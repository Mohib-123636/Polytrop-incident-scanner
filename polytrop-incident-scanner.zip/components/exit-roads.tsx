import type { ExitRoad } from '@/lib/data'
import { formatDateTime, formatUsd } from '@/lib/format'
import { ChainIcon } from '@/components/badges'

export function ExitRoads({ exits }: { exits: ExitRoad[] }) {
  if (exits.length === 0) {
    return <p className="rounded-md border border-border bg-card p-8 text-center text-sm text-muted-foreground">No funds have reached a known service.</p>
  }
  const max = exits[0].usd
  const total = exits.reduce((s, e) => s + e.usd, 0)
  return (
    <div className="flex flex-col rounded-md border border-border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3">
        <div>
          <h3 className="text-sm font-semibold">Exit roads</h3>
          <p className="text-xs text-muted-foreground">Exchanges, bridges, mixers and OTC desks that received tainted value.</p>
        </div>
        <p className="font-mono text-xs text-service">{`${formatUsd(total)} reached services`}</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-left">
          <thead>
            <tr className="border-b border-border font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
              <th scope="col" className="px-4 py-2.5 font-medium">Service</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Type</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Chain</th>
              <th scope="col" className="w-1/3 px-4 py-2.5 font-medium">Received</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Deposits</th>
              <th scope="col" className="px-4 py-2.5 font-medium">First seen</th>
            </tr>
          </thead>
          <tbody>
            {exits.map((e) => (
              <tr key={`${e.service}-${e.chain}`} className="border-b border-border/60 last:border-0 hover:bg-secondary/60">
                <td className="px-4 py-2.5 text-sm font-medium">{e.service}</td>
                <td className="px-4 py-2.5">
                  <span className="rounded-sm border border-border px-1.5 py-0.5 font-mono text-[11px] text-muted-foreground">{e.kind}</span>
                </td>
                <td className="px-4 py-2.5">
                  <ChainIcon chain={e.chain} />
                </td>
                <td className="px-4 py-2.5">
                  <div className="flex items-center gap-3">
                    <div className="h-1.5 flex-1 rounded-full bg-secondary">
                      <div className="h-full rounded-full bg-service" style={{ width: `${Math.max(3, (e.usd / max) * 100)}%` }} />
                    </div>
                    <span className="w-16 text-right font-mono text-sm tabular-nums">{formatUsd(e.usd)}</span>
                  </div>
                </td>
                <td className="px-4 py-2.5 font-mono text-sm tabular-nums">{e.txCount}</td>
                <td className="px-4 py-2.5 whitespace-nowrap font-mono text-xs text-muted-foreground">{formatDateTime(e.firstSeen)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
