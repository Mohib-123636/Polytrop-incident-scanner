export type Chain = 'bitcoin' | 'evm' | 'tron' | 'solana'
export type AddressStatus = 'tainted' | 'frozen' | 'service'
export type ServiceKind = 'CEX' | 'Bridge' | 'Mixer' | 'OTC' | 'Swap'

export type FlaggedAddress = {
  id: string
  address: string
  chain: Chain
  hop: number
  parentId: string | null
  addedAt: string
  lastMoveAt: string
  transferredUsd: number
  downstream: number
  status: AddressStatus
  txHash: string
  label?: string
}

export type ExitRoad = {
  service: string
  kind: ServiceKind
  chain: Chain
  usd: number
  txCount: number
  firstSeen: string
}

export type MainRoute = {
  id: string
  path: { address: string; chain: Chain; status: AddressStatus; label?: string }[]
  usd: number
  hops: number
}

export type Incident = {
  slug: string
  name: string
  victim: string
  attackVector: string
  date: string
  state: 'live' | 'contained' | 'archived'
  chains: Chain[]
  stolenUsd: number
  tracedUsd: number
  frozenUsd: number
  reachedServicesUsd: number
  maxHop: number
  timeToFlagMin: number
  warnedAheadMin: number
  summary: string
  addresses: FlaggedAddress[]
  exits: ExitRoad[]
  routes: MainRoute[]
}

export const CHAIN_LABEL: Record<Chain, string> = {
  bitcoin: 'Bitcoin',
  evm: 'EVM',
  tron: 'Tron',
  solana: 'Solana',
}

export const CHAIN_TICKER: Record<Chain, string> = {
  bitcoin: 'BTC',
  evm: 'ETH',
  tron: 'TRX',
  solana: 'SOL',
}

function mulberry32(seed: number) {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function hashSeed(input: string) {
  let h = 2166136261
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

const HEX = '0123456789abcdef'
const B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'
const B32 = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l'

function randFrom(rand: () => number, alphabet: string, length: number) {
  let out = ''
  for (let i = 0; i < length; i++) out += alphabet[Math.floor(rand() * alphabet.length)]
  return out
}

function makeAddress(rand: () => number, chain: Chain) {
  switch (chain) {
    case 'bitcoin':
      return `bc1q${randFrom(rand, B32, 38)}`
    case 'evm':
      return `0x${randFrom(rand, HEX, 40)}`
    case 'tron':
      return `T${randFrom(rand, B58, 33)}`
    case 'solana':
      return randFrom(rand, B58, 44)
  }
}

function makeTxHash(rand: () => number, chain: Chain) {
  switch (chain) {
    case 'evm':
      return `0x${randFrom(rand, HEX, 64)}`
    case 'solana':
      return randFrom(rand, B58, 88)
    default:
      return randFrom(rand, HEX, 64)
  }
}

const SERVICES: { service: string; kind: ServiceKind; chains: Chain[] }[] = [
  { service: 'Binance', kind: 'CEX', chains: ['bitcoin', 'evm', 'tron', 'solana'] },
  { service: 'OKX', kind: 'CEX', chains: ['bitcoin', 'evm', 'tron', 'solana'] },
  { service: 'HTX', kind: 'CEX', chains: ['tron', 'evm', 'bitcoin'] },
  { service: 'KuCoin', kind: 'CEX', chains: ['evm', 'tron', 'bitcoin'] },
  { service: 'eXch', kind: 'Swap', chains: ['evm', 'bitcoin', 'tron'] },
  { service: 'THORChain', kind: 'Bridge', chains: ['bitcoin', 'evm'] },
  { service: 'Wormhole', kind: 'Bridge', chains: ['solana', 'evm'] },
  { service: 'Tornado Cash', kind: 'Mixer', chains: ['evm'] },
  { service: 'Wasabi CoinJoin', kind: 'Mixer', chains: ['bitcoin'] },
  { service: 'FixedFloat', kind: 'Swap', chains: ['evm', 'bitcoin', 'tron', 'solana'] },
  { service: 'Huione OTC', kind: 'OTC', chains: ['tron'] },
  { service: 'Garantex', kind: 'OTC', chains: ['tron', 'bitcoin'] },
]

type Seed = Omit<Incident, 'addresses' | 'exits' | 'routes' | 'tracedUsd' | 'frozenUsd' | 'reachedServicesUsd' | 'maxHop'> & {
  addressCount: number
  depth: number
  frozenRatio: number
  serviceRatio: number
}

const SEEDS: Seed[] = [
  {
    slug: 'bybit',
    name: 'Bybit Cold Wallet Drain',
    victim: 'Bybit',
    attackVector: 'Compromised multisig signing UI (Safe{Wallet} frontend)',
    date: '2025-02-21T14:13:00Z',
    state: 'contained',
    chains: ['evm', 'bitcoin', 'tron'],
    stolenUsd: 1_460_000_000,
    timeToFlagMin: 4,
    warnedAheadMin: 38,
    summary:
      'Roughly 401K ETH and staked derivatives were moved from a cold multisig after a malicious transaction was signed through a tampered interface. Funds were split across thousands of fresh addresses and laundered through cross-chain swaps into Bitcoin.',
    addressCount: 420,
    depth: 9,
    frozenRatio: 0.06,
    serviceRatio: 0.14,
  },
  {
    slug: 'binance',
    name: 'Binance BSC Token Hub Exploit',
    victim: 'Binance',
    attackVector: 'Forged IAVL proof against the BSC Token Hub bridge',
    date: '2022-10-06T18:26:00Z',
    state: 'archived',
    chains: ['evm'],
    stolenUsd: 570_000_000,
    timeToFlagMin: 11,
    warnedAheadMin: 22,
    summary:
      'An attacker minted 2M BNB by submitting a forged Merkle proof to the cross-chain hub. Validators halted the chain within hours, freezing the majority of the minted supply before it could leave BNB Chain.',
    addressCount: 160,
    depth: 6,
    frozenRatio: 0.62,
    serviceRatio: 0.1,
  },
  {
    slug: 'ronin',
    name: 'Ronin Bridge Validator Compromise',
    victim: 'Sky Mavis / Ronin',
    attackVector: 'Spear-phished validator keys (5 of 9 threshold)',
    date: '2022-03-23T08:42:00Z',
    state: 'archived',
    chains: ['evm', 'bitcoin'],
    stolenUsd: 624_000_000,
    timeToFlagMin: 8640,
    warnedAheadMin: 0,
    summary:
      'Withdrawals of 173,600 ETH and 25.5M USDC were signed with compromised validator keys. The breach went unnoticed for six days, after which funds were routed through mixers and bridges into Bitcoin.',
    addressCount: 260,
    depth: 8,
    frozenRatio: 0.04,
    serviceRatio: 0.18,
  },
  {
    slug: 'dmm-bitcoin',
    name: 'DMM Bitcoin Hot Wallet Theft',
    victim: 'DMM Bitcoin',
    attackVector: 'Social-engineered wallet-software vendor employee',
    date: '2024-05-31T04:26:00Z',
    state: 'archived',
    chains: ['bitcoin'],
    stolenUsd: 305_000_000,
    timeToFlagMin: 26,
    warnedAheadMin: 14,
    summary:
      '4,502.9 BTC left the exchange hot wallet in a single transaction. The funds were peeled through CoinJoin rounds and eventually off-ramped through OTC desks.',
    addressCount: 180,
    depth: 10,
    frozenRatio: 0.02,
    serviceRatio: 0.22,
  },
  {
    slug: 'wazirx',
    name: 'WazirX Multisig Exploit',
    victim: 'WazirX',
    attackVector: 'Signer interface mismatch on a custody multisig',
    date: '2024-07-18T06:18:00Z',
    state: 'contained',
    chains: ['evm', 'tron'],
    stolenUsd: 235_000_000,
    timeToFlagMin: 6,
    warnedAheadMin: 31,
    summary:
      'Over 200 tokens were drained from a Safe multisig after the contract was upgraded to an attacker-controlled implementation. Assets were swapped to ETH and partially bridged to Tron.',
    addressCount: 210,
    depth: 7,
    frozenRatio: 0.09,
    serviceRatio: 0.12,
  },
  {
    slug: 'atomic-wallet',
    name: 'Atomic Wallet User Drain',
    victim: 'Atomic Wallet users',
    attackVector: 'Client-side key extraction across 5,500 wallets',
    date: '2023-06-03T12:00:00Z',
    state: 'archived',
    chains: ['tron', 'evm', 'bitcoin', 'solana'],
    stolenUsd: 100_000_000,
    timeToFlagMin: 95,
    warnedAheadMin: 6,
    summary:
      'Thousands of retail wallets were emptied across multiple chains in a coordinated sweep. Proceeds consolidated on Tron and were cashed out via OTC brokers.',
    addressCount: 240,
    depth: 6,
    frozenRatio: 0.11,
    serviceRatio: 0.26,
  },
  {
    slug: 'solana-dex-drain',
    name: 'Solana DEX Oracle Manipulation',
    victim: 'Solana perpetuals venue',
    attackVector: 'Thin-liquidity oracle manipulation with flash borrows',
    date: '2026-11-09T21:47:00Z',
    state: 'live',
    chains: ['solana', 'evm'],
    stolenUsd: 48_600_000,
    timeToFlagMin: 2,
    warnedAheadMin: 44,
    summary:
      'An attacker inflated collateral value through a manipulated price feed and borrowed against it. Funds are actively bridging out to EVM; propagation is still being traced.',
    addressCount: 120,
    depth: 5,
    frozenRatio: 0.18,
    serviceRatio: 0.08,
  },
]

const HOUR = 3_600_000

function buildIncident(seed: Seed): Incident {
  const rand = mulberry32(hashSeed(seed.slug))
  const start = new Date(seed.date).getTime()
  const addresses: FlaggedAddress[] = []
  const byHop: FlaggedAddress[][] = []

  const pickChain = (hop: number): Chain => {
    if (hop === 0) return seed.chains[0]
    const r = rand()
    if (r < 0.6) return seed.chains[0]
    return seed.chains[Math.floor(rand() * seed.chains.length)]
  }

  const weights = Array.from({ length: seed.depth }, (_, h) => Math.sin(((h + 1) / (seed.depth + 1)) * Math.PI) + 0.25)
  const weightSum = weights.reduce((s, w) => s + w, 0)
  const hopPlan: number[] = [0]
  weights.forEach((w, h) => {
    const count = Math.max(2, Math.round(((seed.addressCount - 1) * w) / weightSum))
    for (let c = 0; c < count; c++) hopPlan.push(h + 1)
  })

  for (let i = 0; i < hopPlan.length; i++) {
    const effectiveHop = hopPlan[i]
    const prev = byHop[effectiveHop - 1] ?? []
    const tainted = prev.filter((p) => p.status === 'tainted')
    const parents = tainted.length ? tainted : prev
    const realParent = effectiveHop > 0 && parents?.length ? parents[Math.floor(rand() * parents.length)] : null
    const chain = pickChain(effectiveHop)

    const decay = Math.pow(0.55, effectiveHop)
    const transferredUsd =
      effectiveHop === 0
        ? seed.stolenUsd
        : Math.round(seed.stolenUsd * decay * (0.02 + rand() * 0.25) * (rand() < 0.08 ? 3 : 1))

    const r = rand()
    const isTerminal = effectiveHop >= seed.depth - 1 || rand() < 0.15
    let status: AddressStatus = 'tainted'
    if (effectiveHop > 0 && r < seed.frozenRatio) status = 'frozen'
    else if (effectiveHop > 1 && isTerminal && r < seed.frozenRatio + seed.serviceRatio) status = 'service'

    const eligible = SERVICES.filter((s) => s.chains.includes(chain))
    const service = status === 'service' ? eligible[Math.floor(Math.pow(rand(), 1.6) * eligible.length)] : undefined

    const addedAt = start + effectiveHop * HOUR * (0.4 + rand() * 6) + rand() * HOUR
    const lastMoveAt = status === 'frozen' ? addedAt + rand() * HOUR * 2 : addedAt + rand() * HOUR * 24 * (effectiveHop + 1)

    const node: FlaggedAddress = {
      id: `${seed.slug}-${i}`,
      address: makeAddress(rand, chain),
      chain,
      hop: effectiveHop,
      parentId: realParent?.id ?? null,
      addedAt: new Date(addedAt).toISOString(),
      lastMoveAt: new Date(lastMoveAt).toISOString(),
      transferredUsd: Math.max(1200, transferredUsd),
      downstream: status === 'tainted' ? Math.floor(rand() * 40 * decay * 4) + (isTerminal ? 0 : 1) : 0,
      status,
      txHash: makeTxHash(rand, chain),
      label: effectiveHop === 0 ? `${seed.victim} exploiter` : service ? `${service.service} deposit` : undefined,
    }
    addresses.push(node)
    ;(byHop[effectiveHop] ??= []).push(node)
  }

  const children = new Map<string, FlaggedAddress[]>()
  for (const a of addresses) if (a.parentId) (children.get(a.parentId) ?? children.set(a.parentId, []).get(a.parentId)!).push(a)
  for (const a of addresses) {
    const kids = children.get(a.id)
    if (!kids?.length) continue
    const weights = kids.map(() => 0.2 + Math.pow(rand(), 2))
    const sum = weights.reduce((s, w) => s + w, 0)
    const forwarded = a.transferredUsd * (0.78 + rand() * 0.2)
    kids.forEach((k, idx) => {
      k.transferredUsd = Math.max(1200, Math.round((forwarded * weights[idx]) / sum))
    })
  }
  const childCount = new Map<string, number>()
  for (const [id, kids] of children) childCount.set(id, kids.length)
  for (const a of addresses) if (a.status === 'tainted') a.downstream = Math.max(a.downstream, childCount.get(a.id) ?? 0)

  const frozenUsd = addresses.filter((a) => a.status === 'frozen').reduce((s, a) => s + a.transferredUsd, 0)
  const reachedServicesUsd = addresses.filter((a) => a.status === 'service').reduce((s, a) => s + a.transferredUsd, 0)
  const tracedUsd = Math.min(
    seed.stolenUsd,
    addresses.filter((a) => a.hop === 1).reduce((s, a) => s + a.transferredUsd, 0),
  )

  const exitMap = new Map<string, ExitRoad>()
  for (const a of addresses) {
    if (a.status !== 'service' || !a.label) continue
    const name = a.label.replace(' deposit', '')
    const meta = SERVICES.find((s) => s.service === name)!
    const key = `${name}-${a.chain}`
    const existing = exitMap.get(key)
    if (existing) {
      existing.usd += a.transferredUsd
      existing.txCount += 1
      if (a.addedAt < existing.firstSeen) existing.firstSeen = a.addedAt
    } else {
      exitMap.set(key, { service: name, kind: meta.kind, chain: a.chain, usd: a.transferredUsd, txCount: 1, firstSeen: a.addedAt })
    }
  }
  const exits = [...exitMap.values()].sort((x, y) => y.usd - x.usd)

  const byId = new Map(addresses.map((a) => [a.id, a]))
  const terminals = addresses
    .filter((a) => a.status === 'service' || a.status === 'frozen')
    .sort((x, y) => y.transferredUsd - x.transferredUsd)
    .slice(0, 8)
  const routes: MainRoute[] = terminals.map((t, idx) => {
    const path: MainRoute['path'] = []
    let cursor: FlaggedAddress | undefined = t
    while (cursor) {
      path.unshift({ address: cursor.address, chain: cursor.chain, status: cursor.status, label: cursor.label })
      cursor = cursor.parentId ? byId.get(cursor.parentId) : undefined
    }
    return { id: `${seed.slug}-route-${idx}`, path, usd: t.transferredUsd, hops: t.hop }
  })

  const { addressCount: _a, depth: _d, frozenRatio: _f, serviceRatio: _s, ...rest } = seed
  return {
    ...rest,
    tracedUsd,
    frozenUsd,
    reachedServicesUsd,
    maxHop: Math.max(...addresses.map((a) => a.hop)),
    addresses,
    exits,
    routes,
  }
}

export const INCIDENTS: Incident[] = SEEDS.map(buildIncident).sort(
  (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
)

export function getIncident(slug: string) {
  return INCIDENTS.find((i) => i.slug === slug)
}

export function getGlobalMetrics() {
  const all = INCIDENTS.flatMap((i) => i.addresses)
  return {
    incidentTotal: INCIDENTS.length,
    liveIncidents: INCIDENTS.filter((i) => i.state === 'live').length,
    tracedVolume: INCIDENTS.reduce((s, i) => s + i.tracedUsd, 0),
    stolenVolume: INCIDENTS.reduce((s, i) => s + i.stolenUsd, 0),
    walletsUnderWatch: all.filter((a) => a.status === 'tainted').length,
    reachedServices: new Set(INCIDENTS.flatMap((i) => i.exits.map((e) => e.service))).size,
    frozenUsd: INCIDENTS.reduce((s, i) => s + i.frozenUsd, 0),
  }
}

export type SearchHit = {
  kind: 'address' | 'transaction' | 'incident'
  incident: Pick<Incident, 'slug' | 'name'>
  address?: FlaggedAddress
}

export function searchIntel(raw: string): SearchHit[] {
  const q = raw.trim().toLowerCase()
  if (q.length < 3) return []
  const hits: SearchHit[] = []
  for (const inc of INCIDENTS) {
    const ref = { slug: inc.slug, name: inc.name }
    if (inc.name.toLowerCase().includes(q) || inc.victim.toLowerCase().includes(q) || inc.slug.includes(q)) {
      hits.push({ kind: 'incident', incident: ref })
    }
    for (const a of inc.addresses) {
      if (a.address.toLowerCase().includes(q)) hits.push({ kind: 'address', incident: ref, address: a })
      else if (a.txHash.toLowerCase().includes(q)) hits.push({ kind: 'transaction', incident: ref, address: a })
      if (hits.length >= 60) return hits
    }
  }
  return hits
}

export function addressesToCsv(rows: FlaggedAddress[], incidentSlug?: string) {
  const header = ['incident', 'address', 'chain', 'hop', 'status', 'transferred_usd', 'downstream', 'added_at', 'last_move_at', 'tx_hash', 'label']
  const lines = rows.map((r) =>
    [incidentSlug ?? r.id.split('-').slice(0, -1).join('-'), r.address, r.chain, r.hop, r.status, r.transferredUsd, r.downstream, r.addedAt, r.lastMoveAt, r.txHash, r.label ?? '']
      .map((v) => `"${String(v).replaceAll('"', '""')}"`)
      .join(','),
  )
  return [header.join(','), ...lines].join('\n')
}

export function exitsToCsv(rows: (ExitRoad & { incident: string })[]) {
  const header = ['incident', 'service', 'kind', 'chain', 'usd', 'tx_count', 'first_seen']
  const lines = rows.map((r) =>
    [r.incident, r.service, r.kind, r.chain, r.usd, r.txCount, r.firstSeen].map((v) => `"${String(v).replaceAll('"', '""')}"`).join(','),
  )
  return [header.join(','), ...lines].join('\n')
}
