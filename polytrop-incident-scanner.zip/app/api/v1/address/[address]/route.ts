import { INCIDENTS } from '@/lib/data'

export async function GET(_request: Request, { params }: { params: Promise<{ address: string }> }) {
  const { address } = await params
  const needle = address.toLowerCase()
  for (const inc of INCIDENTS) {
    const hit = inc.addresses.find((a) => a.address.toLowerCase() === needle)
    if (hit) {
      return Response.json({
        data: { ...hit, risk: hit.status === 'frozen' ? 'blocked' : 'high', incident: { slug: inc.slug, name: inc.name } },
      })
    }
  }
  return Response.json({ data: { address, risk: 'unknown', incident: null } })
}
