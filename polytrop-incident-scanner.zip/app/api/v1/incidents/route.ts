import { INCIDENTS } from '@/lib/data'

export function GET() {
  return Response.json({
    data: INCIDENTS.map(({ addresses, routes, exits, ...rest }) => ({
      ...rest,
      flaggedAddresses: addresses.length,
      exitRoads: exits.length,
    })),
  })
}
