import { getIncident } from '@/lib/data'

export async function GET(_request: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const incident = getIncident(slug)
  if (!incident) return Response.json({ error: 'not_found' }, { status: 404 })
  const { addresses, ...rest } = incident
  return Response.json({ data: { ...rest, flaggedAddresses: addresses.length } })
}
