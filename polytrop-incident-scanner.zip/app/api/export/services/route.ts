import { exitsToCsv, getIncident, INCIDENTS } from '@/lib/data'

export function GET(request: Request) {
  const slug = new URL(request.url).searchParams.get('incident')
  const incidents = slug ? [getIncident(slug)].filter((i) => i !== undefined) : INCIDENTS
  if (slug && incidents.length === 0) return new Response('Incident not found', { status: 404 })

  const rows = incidents.flatMap((inc) => inc.exits.map((e) => ({ ...e, incident: inc.slug })))

  return new Response(exitsToCsv(rows), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="tracewire-services${slug ? `-${slug}` : ''}.csv"`,
    },
  })
}
