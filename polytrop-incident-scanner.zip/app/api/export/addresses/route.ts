import { addressesToCsv, getIncident, INCIDENTS } from '@/lib/data'

export function GET(request: Request) {
  const slug = new URL(request.url).searchParams.get('incident')
  const incidents = slug ? [getIncident(slug)].filter((i) => i !== undefined) : INCIDENTS
  if (slug && incidents.length === 0) return new Response('Incident not found', { status: 404 })

  const csv = incidents.map((inc, i) => {
    const body = addressesToCsv(inc.addresses, inc.slug)
    return i === 0 ? body : body.slice(body.indexOf('\n') + 1)
  })

  return new Response(csv.join('\n'), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="tracewire-addresses${slug ? `-${slug}` : ''}.csv"`,
    },
  })
}
