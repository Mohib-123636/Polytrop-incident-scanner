import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowUpRight, SearchX } from 'lucide-react'
import { searchIntel } from '@/lib/data'
import { formatDateTime, formatUsd } from '@/lib/format'
import { ChainIcon, StatusBadge } from '@/components/badges'
import { HashCell } from '@/components/hash-cell'

export const metadata: Metadata = { title: 'Search' }

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = '' } = await searchParams
  const hits = searchIntel(q)
  const incidents = hits.filter((h) => h.kind === 'incident')
  const matches = hits.filter((h) => h.kind !== 'incident')

  return (
    <main className="mx-auto flex max-w-5xl flex-col gap-8 px-4 py-10 md:px-6">
      <header className="flex flex-col gap-1">
        <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Scan results</p>
        <h1 className="break-all font-mono text-xl font-semibold md:text-2xl">{q || '—'}</h1>
        <p className="text-sm text-muted-foreground">
          {hits.length === 0 ? 'No matches in tracked incidents.' : `${hits.length} match${hits.length === 1 ? '' : 'es'} across tracked incidents.`}
        </p>
      </header>

      {hits.length === 0 && (
        <div className="flex flex-col items-center gap-3 rounded-md border border-border bg-card p-10 text-center">
          <SearchX className="size-6 text-muted-foreground" aria-hidden="true" />
          <p className="max-w-md text-sm leading-relaxed text-muted-foreground">
            {"This address or hash hasn't been linked to a tracked incident. Absence of a flag is not a clearance — check again as traces propagate."}
          </p>
          <Link href="/scanner" className="text-sm underline underline-offset-4">
            Back to scanner
          </Link>
        </div>
      )}

      {incidents.length > 0 && (
        <section className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold">Incidents</h2>
          <ul className="flex flex-col gap-2">
            {incidents.map((h) => (
              <li key={h.incident.slug}>
                <Link
                  href={`/scanner/incident/${h.incident.slug}`}
                  className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 text-sm hover:border-ring"
                >
                  {h.incident.name}
                  <ArrowUpRight className="size-4 text-muted-foreground" aria-hidden="true" />
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}

      {matches.length > 0 && (
        <section className="flex flex-col gap-2">
          <h2 className="text-sm font-semibold">Addresses & transactions</h2>
          <ul className="flex flex-col gap-2">
            {matches.map((h) => {
              const a = h.address!
              return (
                <li key={`${h.kind}-${a.id}`} className="flex flex-col gap-3 rounded-md border border-border bg-card p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <ChainIcon chain={a.chain} />
                      <span className="rounded-sm border border-border px-1.5 py-0.5 font-mono text-[11px] uppercase text-muted-foreground">{h.kind}</span>
                      <StatusBadge status={a.status} />
                    </div>
                    <Link href={`/scanner/incident/${h.incident.slug}`} className="text-xs text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
                      {h.incident.name}
                    </Link>
                  </div>
                  <dl className="grid gap-x-6 gap-y-2 text-xs sm:grid-cols-2 md:grid-cols-4">
                    <div className="flex flex-col gap-0.5 sm:col-span-2">
                      <dt className="text-muted-foreground">Address</dt>
                      <dd><HashCell value={a.address} head={12} tail={8} /></dd>
                    </div>
                    <div className="flex flex-col gap-0.5 sm:col-span-2">
                      <dt className="text-muted-foreground">Transaction</dt>
                      <dd><HashCell value={a.txHash} head={12} tail={8} /></dd>
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <dt className="text-muted-foreground">Transferred</dt>
                      <dd className="font-mono text-sm font-medium">{formatUsd(a.transferredUsd)}</dd>
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <dt className="text-muted-foreground">Hop</dt>
                      <dd className="font-mono text-sm">{`H${a.hop}`}</dd>
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <dt className="text-muted-foreground">Downstream</dt>
                      <dd className="font-mono text-sm">{a.downstream}</dd>
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <dt className="text-muted-foreground">Last move</dt>
                      <dd className="font-mono">{formatDateTime(a.lastMoveAt)}</dd>
                    </div>
                  </dl>
                </li>
              )
            })}
          </ul>
        </section>
      )}
    </main>
  )
}
