import { Suspense } from 'react'
import Link from 'next/link'
import { getGlobalMetrics, INCIDENTS } from '@/lib/data'
import { formatNumber, formatUsd } from '@/lib/format'
import { GlobalSearch } from '@/components/global-search'
import { MetricStrip } from '@/components/metric-strip'
import { IncidentDirectory } from '@/components/incident-directory'
import { AddressTable, type AddressRow } from '@/components/address-table'
import { ExportHub } from '@/components/export-hub'
import { IncidentStateBadge } from '@/components/badges'

export default function ScannerHome() {
  const m = getGlobalMetrics()
  const live = INCIDENTS.find((i) => i.state === 'live')

  const recent: AddressRow[] = INCIDENTS.flatMap((inc) =>
    inc.addresses
      .filter((a) => a.hop > 0)
      .map((a) => ({ ...a, incidentSlug: inc.slug, incidentName: inc.victim })),
  )
    .sort((a, b) => b.transferredUsd - a.transferredUsd)
    .slice(0, 300)

  return (
    <main className="mx-auto flex max-w-7xl flex-col gap-12 px-4 py-10 md:px-6 md:py-14">
      <section className="flex flex-col gap-6">
        {live && (
          <Link
            href={`/scanner/incident/${live.slug}`}
            className="flex w-fit items-center gap-3 rounded-sm border border-tainted/30 bg-tainted/5 px-3 py-1.5 text-xs hover:border-tainted/60"
          >
            <IncidentStateBadge state="live" />
            <span className="text-foreground">{live.name}</span>
            <span className="font-mono text-tainted">{formatUsd(live.stolenUsd)}</span>
          </Link>
        )}
        <div className="flex max-w-3xl flex-col gap-3">
          <h1 className="text-balance text-3xl font-semibold tracking-tight md:text-5xl">
            Follow stolen funds, hop by hop.
          </h1>
          <p className="text-pretty leading-relaxed text-muted-foreground md:text-lg">
            On-chain incident scanner tracing exploit proceeds across Bitcoin, EVM, Tron and Solana — from the first
            drain to the exchange deposit.
          </p>
        </div>
        <div className="max-w-3xl">
          <Suspense fallback={<div className="h-14 rounded-md border border-border bg-card" />}>
            <GlobalSearch size="hero" defaultValue="" />
          </Suspense>
          <p className="mt-2 font-mono text-xs text-muted-foreground">
            {'Try '}
            <Link href={`/scanner/search?q=${INCIDENTS[0].addresses[3].address}`} className="text-foreground underline underline-offset-4">
              {`${INCIDENTS[0].addresses[3].address.slice(0, 14)}…`}
            </Link>
            {' or '}
            <Link href="/scanner/search?q=binance" className="text-foreground underline underline-offset-4">
              binance
            </Link>
          </p>
        </div>
      </section>

      <MetricStrip
        metrics={[
          { label: 'Incident total', value: formatNumber(m.incidentTotal), hint: `${m.liveIncidents} live investigation` },
          { label: 'Traced volume', value: formatUsd(m.tracedVolume), hint: `of ${formatUsd(m.stolenVolume)} stolen` },
          { label: 'Wallets under watch', value: formatNumber(m.walletsUnderWatch), hint: 'Tainted, not yet frozen', tone: 'tainted' },
          { label: 'Reached services', value: formatNumber(m.reachedServices), hint: 'CEX, bridges, OTC, mixers', tone: 'service' },
          { label: 'Frozen', value: formatUsd(m.frozenUsd), hint: 'Blocked by issuers & authorities', tone: 'frozen' },
        ]}
      />

      <section id="directory" className="flex scroll-mt-20 flex-col gap-4">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold tracking-tight">Incident directory</h2>
            <p className="text-sm text-muted-foreground">Major exploits under active or historical trace.</p>
          </div>
        </div>
        <IncidentDirectory incidents={INCIDENTS} />
      </section>

      <section className="flex flex-col gap-4">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">Propagation hop explorer</h2>
          <p className="text-sm text-muted-foreground">Largest tainted transfers across all incidents. Filter by chain, size and status.</p>
        </div>
        <AddressTable rows={recent} showIncident title="Top flagged transfers" />
      </section>

      <section className="flex flex-col gap-4">
        <div>
          <h2 className="text-xl font-semibold tracking-tight">Data & API</h2>
          <p className="text-sm text-muted-foreground">Pull raw intelligence into your compliance or monitoring stack.</p>
        </div>
        <ExportHub />
      </section>
    </main>
  )
}
