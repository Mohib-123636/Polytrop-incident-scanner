import type { Metadata } from 'next'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ChevronLeft } from 'lucide-react'
import { getIncident, INCIDENTS } from '@/lib/data'
import { formatDateTime, formatDuration, formatNumber, formatUsd } from '@/lib/format'
import { ChainIcon, IncidentStateBadge } from '@/components/badges'
import { MetricStrip } from '@/components/metric-strip'
import { IncidentTabs } from '@/components/incident-tabs'
import { MainRoutes } from '@/components/main-routes'
import { ExitRoads } from '@/components/exit-roads'
import { PropagationGraph } from '@/components/propagation-graph'
import { HopDepthChart, type HopBucket } from '@/components/hop-depth-chart'
import { AddressTable } from '@/components/address-table'
import { ExportHub } from '@/components/export-hub'

export function generateStaticParams() {
  return INCIDENTS.map((i) => ({ slug: i.slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  const inc = getIncident(slug)
  if (!inc) return { title: 'Incident not found' }
  return { title: inc.name, description: inc.summary }
}

export default async function IncidentPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const inc = getIncident(slug)
  if (!inc) notFound()

  const buckets: HopBucket[] = Array.from({ length: inc.maxHop }, (_, i) => ({ hop: `H${i + 1}`, tainted: 0, frozen: 0, service: 0 }))
  for (const a of inc.addresses) if (a.hop > 0) buckets[a.hop - 1][a.status] += a.transferredUsd

  const flagged = inc.addresses.filter((a) => a.hop > 0)

  return (
    <main className="mx-auto flex max-w-7xl flex-col gap-8 px-4 py-8 md:px-6 md:py-10">
      <Link href="/scanner#directory" className="flex w-fit items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
        <ChevronLeft className="size-3.5" aria-hidden="true" />
        All incidents
      </Link>

      <header className="flex flex-col gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <IncidentStateBadge state={inc.state} />
          {inc.chains.map((c) => (
            <ChainIcon key={c} chain={c} />
          ))}
          <span className="font-mono text-xs text-muted-foreground">{`${formatDateTime(inc.date)} UTC`}</span>
        </div>
        <h1 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">{inc.name}</h1>
        <p className="max-w-3xl text-pretty leading-relaxed text-muted-foreground">{inc.summary}</p>
        <p className="font-mono text-xs text-muted-foreground">
          {'Vector: '}
          <span className="text-foreground">{inc.attackVector}</span>
        </p>
      </header>

      <MetricStrip
        metrics={[
          { label: 'Total stolen', value: formatUsd(inc.stolenUsd), tone: 'tainted' },
          { label: 'Traced', value: formatUsd(inc.tracedUsd), hint: `${((inc.tracedUsd / inc.stolenUsd) * 100).toFixed(0)}% of proceeds` },
          { label: 'Frozen', value: formatUsd(inc.frozenUsd), tone: 'frozen' },
          { label: 'Reached services', value: formatUsd(inc.reachedServicesUsd), tone: 'service' },
          { label: 'Propagation hops', value: String(inc.maxHop), hint: `${formatNumber(flagged.length)} addresses` },
          {
            label: 'Time to flag',
            value: formatDuration(inc.timeToFlagMin),
            hint: inc.warnedAheadMin > 0 ? `Warned ${inc.warnedAheadMin}m ahead of exit` : 'No advance warning',
          },
        ]}
      />

      <IncidentTabs
        tabs={[
          { id: 'routes', label: 'Main Routes', count: inc.routes.length, content: <MainRoutes routes={inc.routes} /> },
          {
            id: 'full',
            label: 'Full Picture',
            content: (
              <div className="flex flex-col gap-4">
                <PropagationGraph addresses={inc.addresses} />
                <HopDepthChart data={buckets} />
              </div>
            ),
          },
          { id: 'exits', label: 'Exit Roads', count: inc.exits.length, content: <ExitRoads exits={inc.exits} /> },
          { id: 'flagged', label: 'Flagged Addresses', count: flagged.length, content: <AddressTable rows={flagged} /> },
        ]}
      />

      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold tracking-tight">Export this incident</h2>
        <ExportHub incidentSlug={inc.slug} />
      </section>
    </main>
  )
}
