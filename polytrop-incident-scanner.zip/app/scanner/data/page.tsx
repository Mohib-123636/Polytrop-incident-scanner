import type { Metadata } from 'next'
import { ExportHub } from '@/components/export-hub'

export const metadata: Metadata = { title: 'Data & API' }

const ENDPOINTS = [
  { method: 'GET', path: '/api/v1/incidents', body: 'List incidents with stolen, traced, frozen and service totals.' },
  { method: 'GET', path: '/api/v1/incidents/{slug}', body: 'Full incident detail including routes and exit roads.' },
  { method: 'GET', path: '/api/v1/address/{address}', body: 'Risk lookup — status, hop, linked incident and exposure.' },
  { method: 'GET', path: '/api/export/addresses?incident={slug}', body: 'CSV of flagged addresses. Omit incident for all.' },
  { method: 'GET', path: '/api/export/services?incident={slug}', body: 'CSV of services that received tainted value.' },
]

export default function DataPage() {
  return (
    <main className="mx-auto flex max-w-5xl flex-col gap-10 px-4 py-10 md:px-6 md:py-14">
      <header className="flex max-w-2xl flex-col gap-2">
        <h1 className="text-balance text-3xl font-semibold tracking-tight">Data & API</h1>
        <p className="text-pretty leading-relaxed text-muted-foreground">
          Raw intelligence for compliance teams, exchanges and investigators. Download snapshots or integrate the REST API for
          real-time address screening.
        </p>
      </header>
      <ExportHub />
      <section className="flex flex-col gap-3">
        <h2 className="text-lg font-semibold tracking-tight">Endpoints</h2>
        <ul className="overflow-hidden rounded-md border border-border bg-card">
          {ENDPOINTS.map((e) => (
            <li key={e.path} className="flex flex-col gap-1 border-b border-border px-4 py-3 last:border-0 md:flex-row md:items-center md:gap-4">
              <span className="w-fit rounded-sm border border-frozen/40 bg-frozen/10 px-1.5 py-0.5 font-mono text-[11px] font-semibold text-frozen">{e.method}</span>
              <code className="font-mono text-sm">{e.path}</code>
              <span className="text-xs text-muted-foreground md:ml-auto md:text-right">{e.body}</span>
            </li>
          ))}
        </ul>
      </section>
    </main>
  )
}
